.so man3/security_compute_av.3
